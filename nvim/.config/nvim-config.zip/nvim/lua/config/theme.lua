-- ---------- colorscheme ----------
vim.g.gruvbox_material_background = "hard"
vim.g.gruvbox_material_foreground = "material"
vim.g.gruvbox_material_enable_italic = true
vim.g.gruvbox_material_better_performance = true
vim.g.gruvbox_material_transparent_background = 0

pcall(vim.cmd.colorscheme, "gruvbox-material")

-- ---------- transparent editor, opaque Royal Archive popups ----------
local archive = {
  bg = "#050403",
  bg2 = "#0B0A0E",
  surface = "#15100D",
  surface2 = "#211912",
  fg = "#EEE8DA",
  muted = "#8F8778",
  gold = "#D8A657",
  orange = "#C46A3A",
  red = "#B84A4A",
  green = "#A9B665",
}

local function set_transparent_background()
  local hi = vim.api.nvim_set_hl

  vim.o.pumblend = 0
  vim.o.winblend = 0

  -- Main editor: transparent, so Kitty/niri background shows through
  hi(0, "Normal", { fg = archive.fg, bg = "NONE" })
  hi(0, "NormalNC", { fg = archive.fg, bg = "NONE" })
  hi(0, "SignColumn", { fg = archive.muted, bg = "NONE" })
  hi(0, "FoldColumn", { fg = archive.muted, bg = "NONE" })
  hi(0, "LineNr", { fg = archive.muted, bg = "NONE" })
  hi(0, "LineNrAbove", { fg = archive.muted, bg = "NONE" })
  hi(0, "LineNrBelow", { fg = archive.muted, bg = "NONE" })
  hi(0, "CursorLineNr", { fg = archive.gold, bg = archive.surface, bold = true })
  hi(0, "EndOfBuffer", { fg = archive.bg, bg = "NONE" })

  -- Window chrome
  hi(0, "StatusLine", { fg = archive.fg, bg = "NONE" })
  hi(0, "StatusLineNC", { fg = archive.muted, bg = "NONE" })
  hi(0, "TabLine", { fg = archive.muted, bg = "NONE" })
  hi(0, "TabLineFill", { bg = "NONE" })
  hi(0, "TabLineSel", { fg = archive.gold, bg = "NONE", bold = true })
  hi(0, "WinSeparator", { fg = archive.surface2, bg = "NONE" })
  hi(0, "VertSplit", { fg = archive.surface2, bg = "NONE" })
  hi(0, "WinBar", { fg = archive.fg, bg = "NONE" })
  hi(0, "WinBarNC", { fg = archive.muted, bg = "NONE" })

  -- Cursor / selection
  hi(0, "CursorLine", { bg = archive.surface })
  hi(0, "Visual", { bg = archive.surface2 })
  hi(0, "Search", { fg = archive.bg, bg = archive.gold })
  hi(0, "IncSearch", { fg = archive.bg, bg = archive.orange })

  -- Built-in floats: LSP hover, diagnostics, signature help
  hi(0, "NormalFloat", { fg = archive.fg, bg = archive.bg2 })
  hi(0, "FloatBorder", { fg = archive.gold, bg = archive.bg2 })
  hi(0, "FloatTitle", { fg = archive.gold, bg = archive.bg2, bold = true })
  hi(0, "FloatFooter", { fg = archive.muted, bg = archive.bg2 })

  -- Native completion popup / mini.completion
  hi(0, "Pmenu", { fg = archive.fg, bg = archive.bg2 })
  hi(0, "PmenuSel", { fg = archive.bg, bg = archive.gold, bold = true })
  hi(0, "PmenuKind", { fg = archive.orange, bg = archive.bg2 })
  hi(0, "PmenuKindSel", { fg = archive.bg, bg = archive.gold, bold = true })
  hi(0, "PmenuExtra", { fg = archive.muted, bg = archive.bg2 })
  hi(0, "PmenuExtraSel", { fg = archive.bg, bg = archive.gold, bold = true })
  hi(0, "PmenuSbar", { bg = archive.surface })
  hi(0, "PmenuThumb", { bg = archive.gold })
  hi(0, "WildMenu", { fg = archive.bg, bg = archive.gold, bold = true })

  -- Diagnostics
  hi(0, "DiagnosticError", { fg = archive.red })
  hi(0, "DiagnosticWarn", { fg = archive.orange })
  hi(0, "DiagnosticInfo", { fg = archive.gold })
  hi(0, "DiagnosticHint", { fg = archive.muted })

  hi(0, "DiagnosticFloatingError", { fg = archive.red, bg = archive.bg2 })
  hi(0, "DiagnosticFloatingWarn", { fg = archive.orange, bg = archive.bg2 })
  hi(0, "DiagnosticFloatingInfo", { fg = archive.gold, bg = archive.bg2 })
  hi(0, "DiagnosticFloatingHint", { fg = archive.muted, bg = archive.bg2 })

  -- mini.pick
  hi(0, "MiniPickNormal", { fg = archive.fg, bg = archive.bg2 })
  hi(0, "MiniPickBorder", { fg = archive.gold, bg = archive.bg2 })
  hi(0, "MiniPickBorderBusy", { fg = archive.orange, bg = archive.bg2 })
  hi(0, "MiniPickBorderText", { fg = archive.gold, bg = archive.bg2, bold = true })
  hi(0, "MiniPickHeader", { fg = archive.orange, bg = archive.bg2 })
  hi(0, "MiniPickPrompt", { fg = archive.gold, bg = archive.bg2, bold = true })
  hi(0, "MiniPickPromptCaret", { fg = archive.bg, bg = archive.gold })
  hi(0, "MiniPickMatchCurrent", { fg = archive.bg, bg = archive.gold, bold = true })
  hi(0, "MiniPickMatchMarked", { fg = archive.orange, bg = archive.bg2, bold = true })
  hi(0, "MiniPickMatchRanges", { fg = archive.gold, bg = archive.bg2, bold = true })
  hi(0, "MiniPickPreviewLine", { bg = archive.surface })
  hi(0, "MiniPickPreviewRegion", { bg = archive.surface2 })
  hi(0, "MiniPickIconDirectory", { fg = archive.green, bg = archive.bg2 })
  hi(0, "MiniPickIconFile", { fg = archive.fg, bg = archive.bg2 })

  -- mini.files
  hi(0, "MiniFilesNormal", { fg = archive.fg, bg = archive.bg2 })
  hi(0, "MiniFilesBorder", { fg = archive.gold, bg = archive.bg2 })
  hi(0, "MiniFilesBorderModified", { fg = archive.orange, bg = archive.bg2 })
  hi(0, "MiniFilesTitle", { fg = archive.muted, bg = archive.bg2 })
  hi(0, "MiniFilesTitleFocused", { fg = archive.gold, bg = archive.bg2, bold = true })
  hi(0, "MiniFilesCursorLine", { bg = archive.surface })
  hi(0, "MiniFilesDirectory", { fg = archive.green, bg = archive.bg2 })
  hi(0, "MiniFilesFile", { fg = archive.fg, bg = archive.bg2 })

  -- mini.tabline
  hi(0, "MiniTablineCurrent", { fg = archive.gold, bg = "NONE", bold = true })
  hi(0, "MiniTablineVisible", { fg = archive.fg, bg = "NONE" })
  hi(0, "MiniTablineHidden", { fg = archive.muted, bg = "NONE" })
  hi(0, "MiniTablineModifiedCurrent", { fg = archive.orange, bg = "NONE", bold = true })
  hi(0, "MiniTablineModifiedVisible", { fg = archive.orange, bg = "NONE" })
  hi(0, "MiniTablineModifiedHidden", { fg = archive.orange, bg = "NONE" })
  hi(0, "MiniTablineFill", { bg = "NONE" })
  hi(0, "MiniTablineTabpagesection", { fg = archive.bg, bg = archive.gold, bold = true })
end

set_transparent_background()

vim.api.nvim_create_autocmd({ "ColorScheme", "VimEnter", "UIEnter" }, {
  callback = function()
    vim.schedule(set_transparent_background)
  end,
})
