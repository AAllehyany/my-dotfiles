-- ---------- LSP ----------
local map = vim.keymap.set
local MiniCompletion = require("mini.completion")
local MiniExtra = require("mini.extra")

local capabilities = vim.tbl_deep_extend(
  "force",
  vim.lsp.protocol.make_client_capabilities(),
  MiniCompletion.get_lsp_capabilities()
)

vim.lsp.config("*", {
  capabilities = capabilities,
})

vim.lsp.config("gopls", {
  settings = {
    gopls = {
      gofumpt = true,
      staticcheck = true,
      analyses = {
        unusedparams = true,
      },
    },
  },
})

vim.lsp.config("vtsls", {
  settings = {
    vtsls = {
      autoUseWorkspaceTsdk = true,
    },
  },
})

vim.lsp.config("astro", {
  cmd = { "astro-ls", "--stdio" },
  filetypes = { "astro" },
  root_markers = {
    "package.json",
    "astro.config.mjs",
    "astro.config.ts",
    "tsconfig.json",
    "jsconfig.json",
    ".git",
  },
  init_options = {
    typescript = {},
  },
})

vim.lsp.config("pyright", {
  settings = {
    python = {
      analysis = {
        typeCheckingMode = "basic",
        autoSearchPaths = true,
        useLibraryCodeForTypes = true,
      },
    },
  },
})

vim.lsp.config("tailwindcss", {
  filetypes = {
    "astro",
    "html",
    "css",
    "scss",
    "sass",
    "less",
    "postcss",
    "javascript",
    "javascriptreact",
    "typescript",
    "typescriptreact",
    "vue",
    "svelte",
    "mdx",
  },
  settings = {
    tailwindCSS = {
      validate = true,
      classAttributes = {
        "class",
        "className",
        "class:list",
        "classList",
        "ngClass",
      },
      includeLanguages = {
        astro = "html",
        typescriptreact = "html",
        javascriptreact = "html",
      },
      lint = {
        cssConflict = "warning",
        invalidApply = "error",
        invalidScreen = "error",
        invalidVariant = "error",
        invalidConfigPath = "error",
        invalidTailwindDirective = "error",
        recommendedVariantOrder = "warning",
      },
    },
  },
})

vim.lsp.config("emmet_language_server", {
  cmd = { "emmet-language-server", "--stdio" },
  filetypes = {
    "astro",
    "html",
    "css",
    "scss",
    "sass",
    "less",
    "javascriptreact",
    "typescriptreact",
    "typescript"
  },
  root_markers = {
    "package.json",
    ".git",
  },
  init_options = {
    showAbbreviationSuggestions = true,

    -- emmet-language-server supports "always" or "never".
    -- Keep "always" so Emmet still works in Astro markup;
    -- our completion filter hides it inside --- frontmatter.
    showExpandedAbbreviation = "always",

    -- Important: don't make Emmet items snippet-priority items.
    showSuggestionsAsSnippets = false,

    includeLanguages = {
      astro = "html",
      javascriptreact = "html",
      typescriptreact = "html",
      htmlangular = "html",
      typescript = "html"

    },
  },
})

vim.lsp.enable({
  "gopls",
  "vtsls",
  "pyright",
  "astro",
  "emmet_language_server",
  "tailwindcss",
  "roslyn_ls",
  "angularls"
})

vim.api.nvim_create_autocmd("LspAttach", {
  callback = function(ev)
    local opts = { buffer = ev.buf }

    vim.bo[ev.buf].omnifunc = "v:lua.MiniCompletion.completefunc_lsp"

    local function lmap(mode, lhs, rhs, desc)
      map(mode, lhs, rhs, vim.tbl_extend("force", opts, { desc = desc }))
    end

    -- g = go / code navigation through mini.pick when there are multiple results.
    lmap("n", "gd", function()
      MiniExtra.pickers.lsp({ scope = "definition" })
    end, "Go to definition")

    lmap("n", "gD", function()
      MiniExtra.pickers.lsp({ scope = "declaration" })
    end, "Go to declaration")

    lmap("n", "gr", function()
      MiniExtra.pickers.lsp({ scope = "references" })
    end, "Find references/usages")

    lmap("n", "gi", function()
      MiniExtra.pickers.lsp({ scope = "implementation" })
    end, "Find implementations")

    lmap("n", "gy", function()
      MiniExtra.pickers.lsp({ scope = "type_definition" })
    end, "Go to type definition")

    -- docs
    lmap("n", "K", vim.lsp.buf.hover, "Hover documentation")

    -- <leader>l = LSP actions
    lmap("n", "<leader>lr", vim.lsp.buf.rename, "LSP rename")
    lmap({ "n", "v" }, "<leader>la", vim.lsp.buf.code_action, "LSP code action")

    lmap("n", "<leader>lf", function()
      vim.lsp.buf.format({ async = true })
    end, "LSP format")

    lmap("n", "<leader>ld", vim.diagnostic.open_float, "Line diagnostics")

    lmap("n", "<leader>ls", function()
      MiniExtra.pickers.lsp({ scope = "document_symbol" })
    end, "Document symbols")

    lmap("n", "<leader>lS", function()
      MiniExtra.pickers.lsp({ scope = "workspace_symbol" })
    end, "Workspace symbols")

    lmap("n", "<leader>lW", function()
      MiniExtra.pickers.lsp({ scope = "workspace_symbol_live" })
    end, "Workspace symbols live")

    -- diagnostics navigation
    lmap("n", "[d", function()
      vim.diagnostic.jump({ count = -1, float = true })
    end, "Previous diagnostic")

    lmap("n", "]d", function()
      vim.diagnostic.jump({ count = 1, float = true })
    end, "Next diagnostic")

    local client = vim.lsp.get_client_by_id(ev.data.client_id)
    if client and client:supports_method("textDocument/inlayHint") then
      vim.lsp.inlay_hint.enable(false, { bufnr = ev.buf })

      lmap("n", "<leader>lh", function()
        local enabled = vim.lsp.inlay_hint.is_enabled({ bufnr = ev.buf })
        vim.lsp.inlay_hint.enable(not enabled, { bufnr = ev.buf })
      end, "Toggle inlay hints")
    end
  end,
})
