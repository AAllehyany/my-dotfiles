vim.pack.add({
  { src = "https://github.com/nvim-mini/mini.nvim" },
  { src = "https://github.com/neovim/nvim-lspconfig" },
  { src = "https://github.com/sainnhe/gruvbox-material" },
  
  { src = "https://github.com/stevearc/conform.nvim" },
  { src = "https://github.com/arborist-ts/arborist.nvim"}
  
}, { confirm = false })
